package com.example.model

import androidx.compose.runtime.Immutable
import java.util.UUID

@Immutable
data class Channel(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val streamUrl: String = "",
    val category: String = "Football Live",
    val logoUrl: String = ""
)

@Immutable
data class IPTVAdSettings(
    val adEnabled: Boolean = false,
    val adUnitId: String = "ca-app-pub-3940256099942544/5224354917" // Test ad unit ID
)

@Immutable
data class IPTVNotification(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val message: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Immutable
data class SportsNews(
    val id: String = UUID.randomUUID().toString(),
    val titleAr: String = "",
    val titleEn: String = "",
    val descAr: String = "",
    val descEn: String = "",
    val imageUrl: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

enum class MatchStatus {
    LIVE, UPCOMING, FINISHED
}

@Immutable
data class MatchSchedule(
    val id: String = UUID.randomUUID().toString(),
    val homeTeam: String = "",
    val awayTeam: String = "",
    val homeLogo: String = "",
    val awayLogo: String = "",
    val matchTime: String = "",
    val date: String = "",
    val leagueAr: String = "",
    val leagueEn: String = "",
    val status: MatchStatus = MatchStatus.UPCOMING
)

@Immutable
data class AppUser(
    val username: String = "",
    val roleAr: String = "",
    val roleEn: String = "",
    val isOnline: Boolean = false,
    val lastActive: String = "",
    val statusAr: String = "",
    val statusEn: String = "",
    val pin: String = ""
)


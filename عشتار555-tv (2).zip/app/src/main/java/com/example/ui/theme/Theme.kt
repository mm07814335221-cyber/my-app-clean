package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = StadiumGreenPrimary,
    onPrimary = Color(0xFF381E72), // Elegant deep purple text on lavender highlight
    secondary = StadiumGreenSecondary,
    onSecondary = Color(0xFF381E72),
    tertiary = StadiumLimeAccent,
    background = StadiumDarkCharcoal,
    onBackground = TextLightGrey,
    surface = StadiumDarkCard,
    onSurface = Color.White,
    surfaceVariant = StadiumFieldLight,
    onSurfaceVariant = TextLightGrey,
    error = StadiumAlertRed,
    onError = Color(0xFF601410)  // Deep red text on red alert badge
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force Dark mode for premium stadium live feedback
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

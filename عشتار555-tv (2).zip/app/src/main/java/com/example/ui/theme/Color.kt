package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Immersive UI Premium Dark Theme Colors
val StadiumDarkCharcoal = Color(0xFF1C1B1F) // Deep obsidian brown-grey background
val StadiumDarkCard = Color(0xFF2B2930)     // Premium elevated surface card
val StadiumGreenPrimary = Color(0xFFD0BCFF)  // Electric lavender/purple highlights
val StadiumGreenSecondary = Color(0xFFEADDFF)// Warm pastel purple highlights
val StadiumLimeAccent = Color(0xFFD0BCFF)    // High contrast indicator accent
val StadiumAlertRed = Color(0xFFF2B8B5)      // Modern soft error pink-red badge
val StadiumFieldLight = Color(0xFF211F26)    // Dark secondary slate panels

val LightGreenSecondary = Color(0xFFEADDFF)
val DarkGreenSurface = Color(0xFF141318)
val TextLightGrey = Color(0xFFE6E1E5)
val TextMutedGrey = Color(0xFF938F99)

package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Channel
import com.example.model.IPTVNotification
import com.example.ui.components.VideoPlayerView
import com.example.ui.theme.*
import com.example.viewmodel.IPTVViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun MainScreen(viewModel: IPTVViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    // ViewModel states
    val channels by viewModel.channels.collectAsState()
    val adSettings by viewModel.adSettings.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val isDbOnline by viewModel.isFirebaseConfigured.collectAsState()
    val dbUrl by viewModel.activeDatabaseUrl.collectAsState()
    val activeChannel by viewModel.selectedChannel.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val isAdminVerified by viewModel.isAdminAuthenticated.collectAsState()
    val lastPushNotification by viewModel.lastSimulatedNotification.collectAsState()
    val language by viewModel.language.collectAsState()
    val isAdminTabUnlocked by viewModel.isAdminTabUnlocked.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    val layoutDirection = if (language == AppLanguage.AR) {
        androidx.compose.ui.unit.LayoutDirection.Rtl
    } else {
        androidx.compose.ui.unit.LayoutDirection.Ltr
    }

    // Wrap in Directionality context for Arabic RTL support
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalLayoutDirection provides layoutDirection
    ) {
        if (currentUser == null) {
            LoginRegistrationScreen(viewModel = viewModel, language = language)
        } else {
            // Screen padding handling for Edge-to-Edge immersion
            Scaffold(
                modifier = Modifier
                    .fillMaxSize()
                    .background(StadiumDarkCharcoal),
                bottomBar = {
                    BottomNavigationBar(
                        activeTab = currentTab,
                        language = language,
                        isAdminTabUnlocked = isAdminTabUnlocked,
                        onTabSelected = { viewModel.setTab(it) }
                    )
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(StadiumDarkCharcoal)
                ) {
                    // Main content based on active tab selection
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Header Area with Language Switcher
                        HeaderBar(
                            isOnline = isDbOnline,
                            urlAddress = dbUrl,
                            language = language,
                            onLanguageToggle = { viewModel.toggleLanguage() },
                            onUnlockAdmin = { viewModel.unlockAdminTab() },
                            currentUser = currentUser,
                            onLogout = { viewModel.logoutCurrent() }
                        )
                    
                    when (currentTab) {
                        0 -> LiveTvTab(
                            viewModel = viewModel,
                            activeChannel = activeChannel,
                            channels = channels,
                            adEnabled = adSettings.adEnabled,
                            adUnit = adSettings.adUnitId,
                            language = language
                        )
                        1 -> SportsNewsTab(
                            viewModel = viewModel,
                            language = language
                        )
                        2 -> MatchScheduleTab(
                            viewModel = viewModel,
                            language = language
                        )
                        3 -> NotificationInboxTab(
                            notificationsList = notifications,
                            isOnline = isDbOnline,
                            language = language
                        )
                        4 -> AdminConsoleTab(
                            viewModel = viewModel,
                            isVerified = isAdminVerified,
                            channels = channels,
                            isOnline = isDbOnline,
                            dbUrl = dbUrl,
                            language = language
                        )
                    }
                }

                // Realtime FCM Push Toaster simulation feedback
                AnimatedVisibility(
                    visible = lastPushNotification != null,
                    enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(16.dp)
                ) {
                    lastPushNotification?.let { notif ->
                        FcmPushToaster(
                            title = notif.title,
                            message = notif.message,
                            language = language,
                            onDismiss = { viewModel.clearNotificationBubble() }
                        )
                    }
                }
            }
        }
    }
    }
}

@Composable
fun HeaderBar(
    isOnline: Boolean,
    urlAddress: String,
    language: AppLanguage,
    onLanguageToggle: () -> Unit,
    onUnlockAdmin: () -> Unit,
    currentUser: String?,
    onLogout: () -> Unit
) {
    var titleTapCount by remember { mutableStateOf(0) }
    val context = LocalContext.current

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(StadiumDarkCard)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable {
                titleTapCount++
                if (titleTapCount >= 5) {
                    onUnlockAdmin()
                    titleTapCount = 0
                    android.widget.Toast.makeText(
                        context,
                        if (language == AppLanguage.AR) 
                            "تم تفعيل صلاحيات المشرف! تم فتح لوحة التحكم بالأسفل." 
                        else 
                            "Admin Mode Unlocked! Suite Admin tab is now visible.",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                }
            }
        ) {
            Icon(
                imageVector = Icons.Filled.SportsSoccer,
                contentDescription = null,
                tint = StadiumGreenPrimary,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = TranslationKey.APP_NAME.get(language),
                color = Color.White,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.SansSerif,
                letterSpacing = 1.sp
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Display User info & Logout button
            if (currentUser != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(Color.White.copy(alpha = 0.05f), shape = RoundedCornerShape(20.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.1f), shape = RoundedCornerShape(20.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = if (currentUser == "Mhmid2002@@" || currentUser == "admin") Icons.Default.AdminPanelSettings else Icons.Default.AccountCircle,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = if (currentUser == "Mhmid2002@@" || currentUser == "admin") StadiumGreenSecondary else Color.LightGray
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = currentUser,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .background(Color.White.copy(alpha = 0.08f), shape = CircleShape)
                            .clickable { onLogout() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Logout,
                            contentDescription = "Logout",
                            modifier = Modifier.size(12.dp),
                            tint = StadiumAlertRed
                        )
                    }
                }
            }

            // Language selection pill
            TextButton(
                onClick = onLanguageToggle,
                colors = ButtonDefaults.textButtonColors(
                    contentColor = StadiumGreenPrimary
                ),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier
                    .background(Color.White.copy(alpha = 0.05f), shape = RoundedCornerShape(20.dp))
                    .border(1.dp, StadiumGreenPrimary.copy(alpha = 0.4f), shape = RoundedCornerShape(20.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = "Language",
                    modifier = Modifier.size(12.dp),
                    tint = StadiumGreenPrimary
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = if (language == AppLanguage.EN) "عربي" else "English",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            // Database status pill
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .background(
                        if (isOnline) Color(0xFF1B5E20).copy(alpha = 0.2f) else Color(0xFF374151),
                        shape = RoundedCornerShape(20.dp)
                    )
                    .border(
                        width = 1.dp,
                        color = if (isOnline) StadiumGreenPrimary else Color.Gray,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .background(
                            if (isOnline) StadiumGreenPrimary else Color(0xFF9CA3AF),
                            shape = CircleShape
                        )
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isOnline) TranslationKey.FIREBASE_RTDB.get(language) else TranslationKey.SANDBOX_MODE.get(language),
                    color = if (isOnline) StadiumGreenSecondary else Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LiveTvTab(
    viewModel: IPTVViewModel,
    activeChannel: Channel?,
    channels: List<Channel>,
    adEnabled: Boolean,
    adUnit: String,
    language: AppLanguage
) {
    val allCategoryLabel = if (language == AppLanguage.AR) "الكل" else "All"
    var activeCategoryFilter by remember(language) { mutableStateOf(allCategoryLabel) }

    // Categories parsed dynamically from list
    val categories = remember(channels, language) {
        val list = mutableListOf(allCategoryLabel)
        channels.forEach {
            if (it.category.isNotBlank() && !list.contains(it.category)) {
                list.add(it.category)
            }
        }
        list
    }

    // Filter channels
    val filteredChannels = remember(channels, activeCategoryFilter, language) {
        if (activeCategoryFilter == allCategoryLabel) {
            channels
        } else {
            channels.filter { it.category == activeCategoryFilter }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("livetv_tab_column")
    ) {
        // Step 1: High Fidelity Video player viewport
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16 / 9f)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .border(
                        width = 1.dp,
                        brush = Brush.verticalGradient(
                            listOf(StadiumGreenPrimary.copy(alpha = 0.5f), Color.Transparent)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Black)
            ) {
                if (activeChannel != null) {
                    VideoPlayerView(
                        streamUrl = activeChannel.streamUrl,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Filled.LiveTv,
                                contentDescription = null,
                                tint = StadiumGreenPrimary.copy(alpha = 0.5f),
                                modifier = Modifier.size(54.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                TranslationKey.NO_CHANNEL_ONLINE.get(language),
                                color = TextMutedGrey,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }
        }

        // Step 2: Selected stream meta info cell + monetized inline dynamic AD indicator
        item {
            activeChannel?.let { channel ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = channel.name,
                                color = Color.White,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${TranslationKey.CATEGORY.get(language)}: ${channel.category}",
                                color = StadiumGreenSecondary,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        // Share action dummy button
                        IconButton(onClick = {}) {
                            Icon(
                                imageVector = Icons.Filled.Share,
                                contentDescription = TranslationKey.SHARE_CHANNEL.get(language),
                                tint = Color.White
                            )
                        }
                    }

                    // Simulated Inline Banner Ad if setting ad_enabled is TRUE
                    if (adEnabled) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("sponsored_ad_banner"),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B231B)),
                            border = BorderStroke(1.dp, Color(0xFF2E7D32)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFFE0F2F1), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            TranslationKey.SPONSORED.get(language),
                                            color = Color(0xFF00796B),
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            TranslationKey.GET_PREMIUM.get(language),
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            "AdUnit: ${adUnit.take(24)}...",
                                            color = Color.LightGray,
                                            fontSize = 9.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Box(
                                    modifier = Modifier
                                        .background(StadiumGreenPrimary, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                        .clickable { }
                                ) {
                                    Text(
                                        if (language == AppLanguage.AR) "ترقية" else "UPGRADE",
                                        color = StadiumDarkCharcoal,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Step 3: Horizontal category filter chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp, horizontal = 12.dp)
                    .background(Color.Transparent),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    val isSelected = category == activeCategoryFilter
                    Row(
                        modifier = Modifier
                            .background(
                                color = if (isSelected) StadiumGreenPrimary else StadiumFieldLight,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable { activeCategoryFilter = category }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = category,
                            color = if (isSelected) StadiumDarkCharcoal else Color.White,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Step 4: Display channels in grid
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            ) {
                Text(
                    text = "${TranslationKey.AVAILABLE_CHANNELS.get(language)} (${filteredChannels.size})",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                if (filteredChannels.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (language == AppLanguage.AR) "لا توجد قنوات ضمن الفئة '$activeCategoryFilter'" else "No channels added in category '$activeCategoryFilter'",
                            color = TextMutedGrey,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }

        // Channels list rendering
        items(filteredChannels) { channel ->
            val isActive = channel.id == activeChannel?.id

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .clickable { viewModel.selectChannel(channel) }
                    .border(
                        width = 1.dp,
                        color = if (isActive) StadiumGreenPrimary else Color.Transparent,
                        shape = RoundedCornerShape(10.dp)
                    )
                    .testTag("channel_item_${channel.id}"),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isActive) StadiumDarkCard else StadiumFieldLight
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Logo Image Thumbnail
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(StadiumDarkCharcoal),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = channel.logoUrl,
                            contentDescription = "Channel logo",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.2f)))
                        
                        if (isActive) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(StadiumGreenPrimary.copy(alpha = 0.4f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PlayArrow,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1.0f)) {
                        Text(
                            text = channel.name,
                            color = Color.White,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = channel.category,
                            color = if (isActive) StadiumLimeAccent else TextMutedGrey,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // Status soundwave widget if active
                    if (isActive) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            verticalAlignment = Alignment.Bottom,
                            modifier = Modifier.height(14.dp)
                        ) {
                            Box(modifier = Modifier.size(2.dp, 12.dp).background(StadiumGreenPrimary))
                            Box(modifier = Modifier.size(2.dp, 8.dp).background(StadiumGreenPrimary))
                            Box(modifier = Modifier.size(2.dp, 14.dp).background(StadiumGreenPrimary))
                            Box(modifier = Modifier.size(2.dp, 6.dp).background(StadiumGreenPrimary))
                        }
                    } else {
                        Icon(
                            imageVector = Icons.Filled.ChevronRight,
                            contentDescription = null,
                            tint = Color.LightGray
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationInboxTab(notificationsList: List<IPTVNotification>, isOnline: Boolean, language: AppLanguage) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("notifications_tab_container")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.NotificationsActive,
                contentDescription = null,
                tint = StadiumLimeAccent,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                TranslationKey.FCM_BROADCAST_HISTORY.get(language),
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Text(
            text = TranslationKey.SUBMIT_NOTIF_INFO.get(language),
            color = Color.LightGray,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        if (notificationsList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsOff,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        TranslationKey.NO_BROADCASTS_YET.get(language),
                        color = Color.LightGray,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = TranslationKey.ACCESS_ADMIN_TO_BROADCAST.get(language),
                        color = Color.Gray,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp, start = 20.dp, end = 20.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(notificationsList) { notif ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = StadiumFieldLight),
                        border = BorderStroke(0.5.dp, Color(0xFF374151))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.Campaign,
                                        contentDescription = null,
                                        tint = StadiumGreenPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = notif.title,
                                        color = Color.White,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = formatTimestamp(notif.timestamp),
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = notif.message,
                                color = Color.White,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminConsoleTab(
    viewModel: IPTVViewModel,
    isVerified: Boolean,
    channels: List<Channel>,
    isOnline: Boolean,
    dbUrl: String,
    language: AppLanguage
) {
    if (!isVerified) {
        // Simple numeric PIN gating form
        AdminPinPrompt(viewModel = viewModel, language = language)
    } else {
        // Complete Administrative control dashboard suite
        AdminDashboardSuite(
            viewModel = viewModel,
            channels = channels,
            isOnline = isOnline,
            dbUrl = dbUrl,
            language = language
        )
    }
}

@Composable
fun AdminPinPrompt(viewModel: IPTVViewModel, language: AppLanguage) {
    var pinText by remember { mutableStateOf("") }
    val error by viewModel.pinError.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .testTag("admin_pin_panel_column"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = StadiumDarkCard)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = null,
                    tint = StadiumGreenPrimary,
                    modifier = Modifier.size(46.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = TranslationKey.IPTV_SUITE_CREDENTIALS.get(language),
                    color = Color.White,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = TranslationKey.KEY_REQUIRED_MODIFY.get(language),
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )

                // Key visual pin input field
                OutlinedTextField(
                    value = pinText,
                    onValueChange = {
                        if (it.length <= 4) {
                            pinText = it
                            viewModel.resetPinFields()
                        }
                    },
                    label = { Text(TranslationKey.MANAGER_PIN.get(language)) },
                    placeholder = { Text(TranslationKey.ENTER_PIN.get(language)) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StadiumGreenPrimary,
                        unfocusedBorderColor = Color.LightGray,
                        focusedLabelColor = StadiumGreenPrimary,
                        unfocusedLabelColor = Color.LightGray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_pin_input_text_field"),
                )

                if (error != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = error ?: "",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { viewModel.verifyAdminPin(pinText) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("admin_pin_submit_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = StadiumGreenPrimary)
                ) {
                    Text(
                        text = TranslationKey.VERIFY_SYSTEM_KEY.get(language),
                        fontWeight = FontWeight.Bold,
                        color = StadiumDarkCharcoal
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = TranslationKey.DEFAULT_DEV_KEY.get(language),
                    color = StadiumGreenSecondary.copy(alpha = 0.8f),
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun AdminDashboardSuite(
    viewModel: IPTVViewModel,
    channels: List<Channel>,
    isOnline: Boolean,
    dbUrl: String,
    language: AppLanguage
) {
    var adminSection by remember { mutableStateOf(0) } // 0 = Backend/Database/Ads config, 1 = Channels Manager, 2 = Push Alerts, 3 = Users & Activity

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("admin_dashboard_suite_column")
    ) {
        // Quick Section Header Switch Selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(StadiumDarkCard)
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            val sections = listOf(
                TranslationKey.ENGINE.get(language),
                TranslationKey.CHANNELS.get(language),
                TranslationKey.PUSH_ALERTS.get(language),
                if (language == AppLanguage.AR) "المستخدمين والنشاط" else "Users & Activity"
            )
            sections.forEachIndexed { idx, label ->
                val active = adminSection == idx
                TextButton(
                    onClick = { adminSection = idx },
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = if (active) StadiumGreenSecondary else Color.Gray
                    )
                ) {
                    Text(
                        text = label,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 11.sp,
                        color = if (active) StadiumGreenPrimary else Color.Gray
                    )
                }
            }
        }

        // Section contents
        when (adminSection) {
            0 -> BackendSettingsSection(viewModel = viewModel, isOnline = isOnline, dbUrl = dbUrl, language = language)
            1 -> ChannelsManagerSection(viewModel = viewModel, channels = channels, language = language)
            2 -> PushAlertManagerSection(viewModel = viewModel, language = language)
            3 -> UsersManagerSection(viewModel = viewModel, language = language)
        }
    }
}

@Composable
fun BackendSettingsSection(
    viewModel: IPTVViewModel,
    isOnline: Boolean,
    dbUrl: String,
    language: AppLanguage
) {
    val adSettings by viewModel.adSettings.collectAsState()
    val rawFirebaseUrl by viewModel.customFirebaseUrl.collectAsState()

    var editingAdUnit by remember { mutableStateOf(adSettings.adUnitId) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Step 1: RAW FIREBASE CONNECTION PORTAL
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = StadiumDarkCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        TranslationKey.FIREBASE_INTEGRATION.get(language),
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        TranslationKey.ENTER_RTDB_INFO.get(language),
                        color = Color.Gray,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = rawFirebaseUrl,
                        onValueChange = { viewModel.customFirebaseUrl.value = it },
                        label = { Text(TranslationKey.RTDB_URL.get(language)) },
                        placeholder = { Text("https://your-app-rtdb.firebaseio.com/") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = StadiumGreenPrimary,
                            unfocusedBorderColor = Color.Gray
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.applyCustomFirebaseDatabase(rawFirebaseUrl) },
                            colors = ButtonDefaults.buttonColors(containerColor = StadiumGreenPrimary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(TranslationKey.UPDATE_RTDB.get(language), color = StadiumDarkCharcoal, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { viewModel.resetToLocalSandbox() },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.LightGray),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(TranslationKey.RESET_LOCAL_SANDBOX.get(language))
                        }
                    }

                    if (isOnline) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2A1B)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Filled.CheckCircle, null, tint = StadiumGreenPrimary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${if (language == AppLanguage.AR) "متصل" else "Connected"}: ${dbUrl.take(28)}...",
                                    color = Color.White,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Step 2: GENERAL MONETIZATION AD MOB CONTROL PANEL
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = StadiumDarkCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        TranslationKey.ADS_INTEGRATION.get(language),
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (language == AppLanguage.AR) "تحديث هذه الإعدادات يحفظ القيم في قاعدة البيانات فوراً." else "Updating these parameters updates settings in Firebase database instantly.",
                        color = Color.Gray,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Ad_Enabled Toggle Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.MonetizationOn,
                                contentDescription = null,
                                tint = if (adSettings.adEnabled) StadiumLimeAccent else Color.LightGray
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(TranslationKey.TOGGLE_ADS.get(language), color = Color.White, fontWeight = FontWeight.Bold)
                                Text(
                                    if (adSettings.adEnabled) {
                                        if (language == AppLanguage.AR) "الإعلانات المدمجة نشطة في القنوات" else "Active ads active inline"
                                    } else {
                                        if (language == AppLanguage.AR) "تم إخفاء عناصر الإعلانات بالكامل" else "Ad elements collapsed globally"
                                    },
                                    color = Color.LightGray,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Switch(
                            checked = adSettings.adEnabled,
                            onCheckedChange = { viewModel.toggleAds(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = StadiumGreenPrimary,
                                checkedTrackColor = StadiumGreenPrimary.copy(alpha = 0.4f),
                                uncheckedThumbColor = Color.LightGray,
                                uncheckedTrackColor = Color.DarkGray
                            ),
                            modifier = Modifier.testTag("admin_ad_enabled_toggle_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Ad Unit String Update
                    OutlinedTextField(
                        value = editingAdUnit,
                        onValueChange = { editingAdUnit = it },
                        label = { Text(TranslationKey.AD_UNIT_ID.get(language)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = StadiumGreenPrimary,
                            unfocusedBorderColor = Color.Gray
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = { viewModel.updateAdUnit(editingAdUnit) },
                        colors = ButtonDefaults.buttonColors(containerColor = StadiumGreenSecondary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(TranslationKey.APPLY_AD_CHANGES.get(language), color = StadiumDarkCharcoal, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Security key logout action
        item {
            Button(
                onClick = { viewModel.logoutAdmin() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Logout, null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(TranslationKey.LOGOUT_ADMIN.get(language))
            }
        }
    }
}

@Composable
fun ChannelsManagerSection(viewModel: IPTVViewModel, channels: List<Channel>, language: AppLanguage) {
    val name by viewModel.newChannelName.collectAsState()
    val url by viewModel.newChannelUrl.collectAsState()
    val category by viewModel.newChannelCategory.collectAsState()
    val logo by viewModel.newChannelLogo.collectAsState()

    var isAddingChannelFormShowing by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Toggle action button to display form
        item {
            Button(
                onClick = { isAddingChannelFormShowing = !isAddingChannelFormShowing },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isAddingChannelFormShowing) Color.DarkGray else StadiumGreenPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = if (isAddingChannelFormShowing) Icons.Filled.Close else Icons.Filled.Add,
                    contentDescription = null,
                    tint = if (isAddingChannelFormShowing) Color.White else StadiumDarkCharcoal
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isAddingChannelFormShowing) (if (language == AppLanguage.AR) "تصغير النموذج" else "Collapse Form") else TranslationKey.ADD_NEW_CHANNEL.get(language),
                    color = if (isAddingChannelFormShowing) Color.White else StadiumDarkCharcoal,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Adding form container
        if (isAddingChannelFormShowing) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = StadiumDarkCard)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            TranslationKey.CHANNEL_FORM.get(language),
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = name,
                            onValueChange = { viewModel.newChannelName.value = it },
                            label = { Text(TranslationKey.CHANNEL_NAME.get(language)) },
                            placeholder = { Text("Sky Sports Live") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = StadiumGreenPrimary,
                                unfocusedBorderColor = Color.LightGray
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = url,
                            onValueChange = { viewModel.newChannelUrl.value = it },
                            label = { Text(TranslationKey.STREAM_URL.get(language)) },
                            placeholder = { Text("https://host.com/live/playlist.m3u8") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = StadiumGreenPrimary,
                                unfocusedBorderColor = Color.LightGray
                            ),
                            modifier = Modifier.fillMaxWidth()
                         )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Category text field
                        OutlinedTextField(
                            value = category,
                            onValueChange = { viewModel.newChannelCategory.value = it },
                            label = { Text(TranslationKey.CATEGORY_LABEL.get(language)) },
                            placeholder = { Text("Premier League, Champions League") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = StadiumGreenPrimary,
                                unfocusedBorderColor = Color.LightGray
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = logo,
                            onValueChange = { viewModel.newChannelLogo.value = it },
                            label = { Text(TranslationKey.LOGO_URL.get(language)) },
                            placeholder = { Text(if (language == AppLanguage.AR) "اتركه فارغاً للافتراضي" else "Leave empty for defaults") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = StadiumGreenPrimary,
                                unfocusedBorderColor = Color.LightGray
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                viewModel.createChannel()
                                isAddingChannelFormShowing = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StadiumGreenPrimary),
                            modifier = Modifier.fillMaxWidth(),
                            enabled = name.isNotBlank() && url.isNotBlank()
                        ) {
                            Text(
                                TranslationKey.SUBMIT_TO_DB.get(language),
                                fontWeight = FontWeight.Bold,
                                color = StadiumDarkCharcoal
                            )
                        }
                    }
                }
            }
        }

        // List & Destroy of channels
        item {
            Text(
                "${TranslationKey.ACTIVE_CHANNELS.get(language)} (${channels.size})",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        if (channels.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (language == AppLanguage.AR) "لا توجد قنوات مسجلة حالياً." else "No channels registered.", color = Color.Gray)
                }
            }
        } else {
            items(channels) { channel ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = StadiumDarkCard)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(0.85f)
                        ) {
                            AsyncImage(
                                model = channel.logoUrl,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.Black),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    channel.name,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    channel.category,
                                    color = StadiumLimeAccent,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        // Destroy Button
                        IconButton(
                            onClick = { viewModel.removeChannel(channel.id) },
                            modifier = Modifier.weight(0.15f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = TranslationKey.REMOVE.get(language),
                                tint = StadiumAlertRed
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PushAlertManagerSection(viewModel: IPTVViewModel, language: AppLanguage) {
    val title by viewModel.pushTitle.collectAsState()
    val message by viewModel.pushMessage.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = StadiumDarkCard)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Campaign,
                        contentDescription = null,
                        tint = StadiumGreenPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = TranslationKey.FCM_FORM.get(language),
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = TranslationKey.NOTIF_DESC.get(language),
                    color = Color.Gray,
                    style = MaterialTheme.typography.bodySmall
                )

                // Input for Title
                OutlinedTextField(
                    value = title,
                    onValueChange = { viewModel.pushTitle.value = it },
                    label = { Text(TranslationKey.HEADLINE_TITLE.get(language)) },
                    placeholder = { Text("⚽ Arsenal vs Chelsea Live!") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = StadiumGreenPrimary,
                        unfocusedBorderColor = Color.LightGray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Input for Message
                OutlinedTextField(
                    value = message,
                    onValueChange = { viewModel.pushMessage.value = it },
                    label = { Text(TranslationKey.MESSAGE_BODY.get(language)) },
                    placeholder = { Text("Click here to play the match immediately!") },
                    minLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = StadiumGreenPrimary,
                        unfocusedBorderColor = Color.LightGray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Button to TRANSMIT
                Button(
                    onClick = { viewModel.triggerBroadcastNotification() },
                    colors = ButtonDefaults.buttonColors(containerColor = StadiumGreenPrimary),
                    enabled = title.isNotBlank() && message.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("admin_fcm_transmit_button")
                ) {
                    Icon(imageVector = Icons.Filled.Send, contentDescription = null, tint = StadiumDarkCharcoal)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = TranslationKey.TRANSMIT_ALERT.get(language),
                        fontWeight = FontWeight.Bold,
                        color = StadiumDarkCharcoal
                    )
                }
            }
        }
    }
}

@Composable
fun FcmPushToaster(
    title: String,
    message: String,
    language: AppLanguage,
    onDismiss: () -> Unit
) {
    // Top drop-down banner representing real-time client reception of FCM alerts!
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(2.dp, StadiumGreenPrimary, RoundedCornerShape(12.dp))
            .clickable { onDismiss() }
            .testTag("fcm_alert_toast_card"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = StadiumDarkCard),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .background(Color(0xFF1B5E20), CircleShape)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Sports,
                    contentDescription = null,
                    tint = StadiumGreenPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (language == AppLanguage.AR) "🔔 تنبيه بث مباشر" else "🔔 BROADCAST ALERT",
                    color = StadiumGreenSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = title,
                    color = Color.White,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = message,
                    color = Color.LightGray,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(onClick = onDismiss) {
                Icon(Icons.Filled.Close, contentDescription = if (language == AppLanguage.AR) "إغلاق" else "Close", tint = Color.LightGray)
            }
        }
    }
}

@Composable
fun BottomNavigationBar(
    activeTab: Int, 
    language: AppLanguage, 
    isAdminTabUnlocked: Boolean,
    onTabSelected: (Int) -> Unit
) {
    NavigationBar(
        containerColor = StadiumDarkCard,
        contentColor = Color.White,
        modifier = Modifier.height(72.dp)
    ) {
        NavigationBarItem(
            selected = activeTab == 0,
            onClick = { onTabSelected(0) },
            icon = {
                Icon(
                    imageVector = Icons.Filled.LiveTv,
                    contentDescription = "Streams"
                )
            },
            label = { Text(TranslationKey.LIVE_ARENA.get(language), fontSize = 9.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = StadiumDarkCharcoal,
                selectedTextColor = StadiumGreenPrimary,
                indicatorColor = StadiumGreenPrimary,
                unselectedIconColor = Color.Gray,
                unselectedTextColor = Color.Gray
            ),
            modifier = Modifier.testTag("nav_item_live")
        )

        NavigationBarItem(
            selected = activeTab == 1,
            onClick = { onTabSelected(1) },
            icon = {
                Icon(
                    imageVector = Icons.Filled.Description,
                    contentDescription = "News"
                )
            },
            label = { Text(TranslationKey.NEWS_FEED.get(language), fontSize = 9.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = StadiumDarkCharcoal,
                selectedTextColor = StadiumGreenPrimary,
                indicatorColor = StadiumGreenPrimary,
                unselectedIconColor = Color.Gray,
                unselectedTextColor = Color.Gray
            ),
            modifier = Modifier.testTag("nav_item_news")
        )

        NavigationBarItem(
            selected = activeTab == 2,
            onClick = { onTabSelected(2) },
            icon = {
                Icon(
                    imageVector = Icons.Filled.DateRange,
                    contentDescription = "Schedule"
                )
            },
            label = { Text(TranslationKey.MATCH_SCHEDULE.get(language), fontSize = 9.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = StadiumDarkCharcoal,
                selectedTextColor = StadiumGreenPrimary,
                indicatorColor = StadiumGreenPrimary,
                unselectedIconColor = Color.Gray,
                unselectedTextColor = Color.Gray
            ),
            modifier = Modifier.testTag("nav_item_schedule")
        )

        NavigationBarItem(
            selected = activeTab == 3,
            onClick = { onTabSelected(3) },
            icon = {
                Icon(
                    imageVector = Icons.Filled.Campaign,
                    contentDescription = "Alerts"
                )
            },
            label = { Text(TranslationKey.ALERTS_TICKER.get(language), fontSize = 9.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = StadiumDarkCharcoal,
                selectedTextColor = StadiumGreenPrimary,
                indicatorColor = StadiumGreenPrimary,
                unselectedIconColor = Color.Gray,
                unselectedTextColor = Color.Gray
            ),
            modifier = Modifier.testTag("nav_item_notifs")
        )

        if (isAdminTabUnlocked) {
            NavigationBarItem(
                selected = activeTab == 4,
                onClick = { onTabSelected(4) },
                icon = {
                    Icon(
                        imageVector = Icons.Filled.AdminPanelSettings,
                        contentDescription = "Admin"
                    )
                },
                label = { Text(TranslationKey.SUITE_ADMIN.get(language), fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = StadiumDarkCharcoal,
                    selectedTextColor = StadiumGreenPrimary,
                    indicatorColor = StadiumGreenPrimary,
                    unselectedIconColor = Color.Gray,
                    unselectedTextColor = Color.Gray
                ),
                modifier = Modifier.testTag("nav_item_admin")
            )
        }
    }
}

private fun formatTimestamp(timestamp: Long): String {
    val date = java.util.Date(timestamp)
    val format = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault())
    return format.format(date)
}

@Composable
fun SportsNewsTab(
    viewModel: IPTVViewModel,
    language: AppLanguage
) {
    val newsList by viewModel.sportsNews.collectAsState()
    var selectedNews by remember { mutableStateOf<com.example.model.SportsNews?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = TranslationKey.NEWS_FEED.get(language),
                color = StadiumGreenPrimary,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (language == AppLanguage.AR) "تابع أحدث الأخبار والتحليلات الرياضية الحصرية أولاً بأول." else "Firsthand exclusive sports news, expert reporting, and updates.",
                color = Color.LightGray,
                style = MaterialTheme.typography.bodySmall
            )
        }

        items(newsList) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = StadiumDarkCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedNews = item }
            ) {
                Column {
                    AsyncImage(
                        model = item.imageUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                    )
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(StadiumGreenPrimary.copy(alpha = 0.1f), shape = RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (language == AppLanguage.AR) "عاجل" else "TRENDING",
                                    color = StadiumGreenSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                            Text(
                                text = formatTimestamp(item.timestamp),
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (language == AppLanguage.AR) item.titleAr else item.titleEn,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (language == AppLanguage.AR) item.descAr else item.descEn,
                            color = Color.LightGray,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }

    // Detail Dialog
    selectedNews?.let { news ->
        AlertDialog(
            onDismissRequest = { selectedNews = null },
            containerColor = StadiumDarkCard,
            tonalElevation = 6.dp,
            title = {
                Text(
                    text = if (language == AppLanguage.AR) news.titleAr else news.titleEn,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
            },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    item {
                        AsyncImage(
                            model = news.imageUrl,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (language == AppLanguage.AR) news.descAr else news.descEn,
                            color = Color.LightGray,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { selectedNews = null },
                    colors = ButtonDefaults.textButtonColors(contentColor = StadiumGreenPrimary)
                ) {
                    Text(text = if (language == AppLanguage.AR) "موافق" else "Close")
                }
            }
        )
    }
}

@Composable
fun MatchScheduleTab(
    viewModel: IPTVViewModel,
    language: AppLanguage
) {
    val matches by viewModel.matchSchedule.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = TranslationKey.MATCH_SCHEDULE.get(language),
                color = StadiumGreenPrimary,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (language == AppLanguage.AR) "جدول مباريات اليوم والغد ومواعيد البث المباشر المحدثة." else "Schedule of football matches for today and tomorrow with kickoff details.",
                color = Color.LightGray,
                style = MaterialTheme.typography.bodySmall
            )
        }

        items(matches) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = StadiumDarkCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        BorderStroke(
                            1.dp,
                            if (item.status == com.example.model.MatchStatus.LIVE) StadiumGreenPrimary.copy(alpha = 0.5f) else Color.Transparent
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Match header (league with icon)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = null,
                                tint = StadiumGreenSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (language == AppLanguage.AR) item.leagueAr else item.leagueEn,
                                color = StadiumGreenSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // State label (Live, upcoming or finished)
                        Box(
                            modifier = Modifier
                                .background(
                                    when (item.status) {
                                        com.example.model.MatchStatus.LIVE -> StadiumAlertRed.copy(alpha = 0.15f)
                                        com.example.model.MatchStatus.UPCOMING -> Color.White.copy(alpha = 0.05f)
                                        com.example.model.MatchStatus.FINISHED -> Color.Gray.copy(alpha = 0.15f)
                                    },
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = when (item.status) {
                                    com.example.model.MatchStatus.LIVE -> TranslationKey.STATUS_LIVE.get(language)
                                    com.example.model.MatchStatus.UPCOMING -> TranslationKey.STATUS_UPCOMING.get(language)
                                    com.example.model.MatchStatus.FINISHED -> TranslationKey.STATUS_FINISHED.get(language)
                                },
                                color = when (item.status) {
                                    com.example.model.MatchStatus.LIVE -> StadiumAlertRed
                                    com.example.model.MatchStatus.UPCOMING -> StadiumGreenPrimary
                                    com.example.model.MatchStatus.FINISHED -> Color.LightGray
                                },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Team comparison Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Home team
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            AsyncImage(
                                model = item.homeLogo,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.05f))
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = item.homeTeam,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                        }

                        // Score or VS indicator
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (item.status == com.example.model.MatchStatus.FINISHED || item.status == com.example.model.MatchStatus.LIVE) item.matchTime else TranslationKey.VS_TEXT.get(language),
                                color = if (item.status == com.example.model.MatchStatus.LIVE) StadiumAlertRed else Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = item.date,
                                color = Color.Gray,
                                fontSize = 10.sp
                            )
                        }

                        // Away team
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            AsyncImage(
                                model = item.awayLogo,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.05f))
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = item.awayTeam,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LoginRegistrationScreen(
    viewModel: IPTVViewModel,
    language: AppLanguage
) {
    var isLoginMode by remember { mutableStateOf(true) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    
    val authError by viewModel.authError.collectAsState()
    val context = LocalContext.current

    // Set default direction based on default Arabic language setting
    val layoutDirection = if (language == AppLanguage.AR) {
        androidx.compose.ui.unit.LayoutDirection.Rtl
    } else {
        androidx.compose.ui.unit.LayoutDirection.Ltr
    }

    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalLayoutDirection provides layoutDirection
    ) {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(StadiumDarkCharcoal)
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(StadiumDarkCharcoal, Color(0xFF0F1E15))
                        )
                    )
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 450.dp)
                        .background(StadiumDarkCard, shape = RoundedCornerShape(24.dp))
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Title and App Mascot Icons
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .background(StadiumGreenPrimary.copy(alpha = 0.1f), shape = CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SportsSoccer,
                            contentDescription = null,
                            tint = StadiumGreenPrimary,
                            modifier = Modifier.size(44.dp)
                        )
                    }

                    Text(
                        text = if (language == AppLanguage.AR) "عشتار Tv" else "Ishtar TV",
                        color = Color.White,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )

                    Text(
                        text = if (language == AppLanguage.AR) {
                            if (isLoginMode) "تسجيل الدخول لمتابعة البث المباشر" else "إنشاء حساب جديد للوصول للقنوات"
                        } else {
                            if (isLoginMode) "Login to access real-time streams" else "Create account to access live streams"
                        },
                        color = Color.LightGray,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Username input
                    OutlinedTextField(
                        value = username,
                        onValueChange = {
                            username = it
                            viewModel.clearAuthError()
                        },
                        label = {
                            Text(
                                if (language == AppLanguage.AR) "اسم المستخدم" else "Username"
                            )
                        },
                        placeholder = {
                            Text(
                                if (language == AppLanguage.AR) "مثال: admin أو user1" else "Type username..."
                            )
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = StadiumGreenPrimary,
                            unfocusedBorderColor = Color.Gray,
                            focusedLabelColor = StadiumGreenPrimary,
                            unfocusedLabelColor = Color.LightGray
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("auth_username_input")
                    )

                    // Password input
                    OutlinedTextField(
                        value = password,
                        onValueChange = {
                            password = it
                            viewModel.clearAuthError()
                        },
                        label = {
                            Text(
                                if (language == AppLanguage.AR) "كلمة المرور" else "Password"
                            )
                        },
                        placeholder = {
                            Text(
                                if (language == AppLanguage.AR) "أدخل كلمة المرور" else "Type password..."
                            )
                        },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = StadiumGreenPrimary,
                            unfocusedBorderColor = Color.Gray,
                            focusedLabelColor = StadiumGreenPrimary,
                            unfocusedLabelColor = Color.LightGray
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("auth_password_input")
                    )

                    // Warning / Error notification
                    authError?.let { err ->
                        Text(
                            text = err,
                            color = StadiumAlertRed,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Primary login / register submit button
                    Button(
                        onClick = {
                            if (isLoginMode) {
                                val success = viewModel.loginUser(username, password)
                                if (success) {
                                    android.widget.Toast.makeText(
                                        context,
                                        if (language == AppLanguage.AR) "تم تسجيل الدخول بنجاح!" else "Logged in successfully!",
                                        android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } else {
                                val success = viewModel.registerUser(username, password)
                                if (success) {
                                    android.widget.Toast.makeText(
                                        context,
                                        if (language == AppLanguage.AR) "تم تسجيل الحساب الجديد بنجاح!" else "Account registered successfully!",
                                        android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StadiumGreenPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("auth_submit_button")
                    ) {
                        Text(
                            text = if (language == AppLanguage.AR) {
                                if (isLoginMode) "تسجيل الدخول" else "إنشاء الحساب الجديد"
                            } else {
                                if (isLoginMode) "Login Now" else "Sign Up"
                            },
                            color = StadiumDarkCharcoal,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    // Mode toggler button
                    TextButton(
                        onClick = {
                            isLoginMode = !isLoginMode
                            viewModel.clearAuthError()
                        }
                    ) {
                        Text(
                            text = if (language == AppLanguage.AR) {
                                if (isLoginMode) "ليس لديك حساب؟ سجل الآن مجاناً" else "لديك حساب بالفعل؟ سجل دخولك"
                            } else {
                                if (isLoginMode) "New to Ishtar? Create an account" else "Already registered? Login here"
                            },
                            color = StadiumGreenSecondary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }

                    // Admin preseed hints to guide them
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.02f), shape = RoundedCornerShape(8.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.05f), shape = RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = if (language == AppLanguage.AR) {
                                "💡 حساب المسؤول الرئيسي المخصص هو:\nاسم المستخدم: Mhmid2002@@\nكلمة المرور: Mhmidmilk200\n(سيفتح لك التطبيق مع لوحة التحكم مباشرة)"
                            } else {
                                "💡 Super Administrator account credentials:\nUsername: Mhmid2002@@\nPassword: Mhmidmilk200\n(Launches the app with Admin Controls directly)"
                            },
                            color = Color.Gray,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun UsersManagerSection(viewModel: IPTVViewModel, language: AppLanguage) {
    val users by viewModel.appUsers.collectAsState()
    
    // Quick statistics
    val totalUsers = users.size
    val onlineCount = users.count { it.isOnline }
    val blockedCount = users.count { it.statusAr.contains("محظور") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Stats Cards bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Total
            Card(
                modifier = Modifier.weight(1.5f),
                colors = CardDefaults.cardColors(containerColor = StadiumDarkCard)
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (language == AppLanguage.AR) "إجمالي المستخدمين" else "Total Users",
                        color = Color.LightGray,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = totalUsers.toString(),
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            // Online Count
            Card(
                modifier = Modifier.weight(1.5f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF132219))
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(StadiumGreenPrimary, shape = CircleShape)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (language == AppLanguage.AR) "النشطين الآن" else "Active Online",
                            color = StadiumGreenSecondary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = onlineCount.toString(),
                        color = StadiumGreenPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            // Blocked Count
            Card(
                modifier = Modifier.weight(1.5f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2B1212))
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (language == AppLanguage.AR) "الحسابات المحظورة" else "Blocked Accounts",
                        color = Color(0xFFEF9A9A),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = blockedCount.toString(),
                        color = Color(0xFFEF5350),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }

        Text(
            text = if (language == AppLanguage.AR) "تفاصيل الحسابات والنشاط الجاري" else "Registered Users List & Activity",
            color = Color.White,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 2.dp)
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(users.size) { idx ->
                val user = users[idx]
                val isSelf = user.username == "Mhmid2002@@" || user.username == "admin"
                val isBlocked = user.statusAr.contains("محظور")

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (user.isOnline) Color(0xFF132219) else StadiumDarkCard
                    ),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (user.isOnline) StadiumGreenPrimary.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.05f)
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // User meta
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(
                                            if (user.isOnline) StadiumGreenPrimary.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.05f),
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (user.username == "Mhmid2002@@" || user.username == "admin") Icons.Filled.AdminPanelSettings else Icons.Filled.Person,
                                        contentDescription = null,
                                        tint = if (user.isOnline) StadiumGreenPrimary else Color.LightGray,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = user.username,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        if (isSelf) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0xFFFFD54F).copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = if (language == AppLanguage.AR) "أنت" else "YOU",
                                                    color = Color(0xFFFFC107),
                                                    fontSize = 8.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = if (language == AppLanguage.AR) user.roleAr else user.roleEn,
                                        color = if (user.username == "Mhmid2002@@" || user.username == "admin") Color(0xFFFFC107) else Color.Gray,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            // Pulse Status pill
                            Column(horizontalAlignment = Alignment.End) {
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (user.isOnline) StadiumGreenPrimary.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.05f),
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .background(
                                                    if (user.isOnline) StadiumGreenPrimary else Color.Gray,
                                                    shape = CircleShape
                                                )
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (user.isOnline) {
                                                if (language == AppLanguage.AR) "نشط الآن" else "Active Now"
                                            } else {
                                                if (language == AppLanguage.AR) "مغلق" else "Offline"
                                            },
                                            color = if (user.isOnline) StadiumGreenPrimary else Color.LightGray,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (user.isOnline) {
                                        if (language == AppLanguage.AR) "نشط بجهازك" else "Active device"
                                    } else {
                                        "${if (language == AppLanguage.AR) "آخر ظهور:" else "Last activity:"} ${user.lastActive}"
                                    },
                                    color = Color.Gray,
                                    fontSize = 8.sp
                                )
                            }
                        }

                        // Password / auth info & controls row
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.15f), shape = RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.Key,
                                    contentDescription = null,
                                    tint = StadiumGreenSecondary,
                                    modifier = Modifier.size(11.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "${if (language == AppLanguage.AR) "رمز الدخول (PIN):" else "PIN Code:"} ",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = user.pin,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            // Block Status string
                            Text(
                                text = if (language == AppLanguage.AR) user.statusAr else user.statusEn,
                                color = if (isBlocked) StadiumAlertRed else StadiumGreenSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Action Buttons (Only for other standard users)
                        if (!isSelf) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Toggle Online / Simulation
                                OutlinedButton(
                                    onClick = { viewModel.toggleUserOnlineStatus(user.username) },
                                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.3f)),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(30.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Wifi,
                                        contentDescription = null,
                                        modifier = Modifier.size(10.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (user.isOnline) {
                                            if (language == AppLanguage.AR) "قطع الاتصال" else "Set Offline"
                                        } else {
                                            if (language == AppLanguage.AR) "محاكاة نشاط" else "Simulate Online"
                                        },
                                        fontSize = 9.sp
                                    )
                                }

                                // Toggle Block
                                Button(
                                    onClick = { viewModel.toggleUserBlock(user.username) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isBlocked) StadiumGreenSecondary else Color(0xFFFF9E9E)
                                    ),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(30.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isBlocked) Icons.Filled.Check else Icons.Filled.Block,
                                        contentDescription = null,
                                        tint = if (isBlocked) StadiumDarkCharcoal else Color(0xFFC62828),
                                        modifier = Modifier.size(10.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isBlocked) {
                                            if (language == AppLanguage.AR) "فك الحظر" else "Unblock User"
                                        } else {
                                            if (language == AppLanguage.AR) "حظر المستخدم" else "Block User"
                                        },
                                        color = if (isBlocked) StadiumDarkCharcoal else Color(0xFFC62828),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


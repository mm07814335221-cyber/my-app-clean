package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.Channel
import com.example.model.IPTVAdSettings
import com.example.model.IPTVNotification
import com.example.model.MatchSchedule
import com.example.model.MatchStatus
import com.example.model.SportsNews
import com.example.repository.FirebaseRepository
import com.example.ui.screens.AppLanguage
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class IPTVViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = FirebaseRepository(application.applicationContext)

    // Exposed flows from repository
    val channels: StateFlow<List<Channel>> = repository.channels
    val adSettings: StateFlow<IPTVAdSettings> = repository.adSettings
    val notifications: StateFlow<List<IPTVNotification>> = repository.notifications
    val isFirebaseConfigured: StateFlow<Boolean> = repository.isFirebaseConfigured
    val activeDatabaseUrl: StateFlow<String> = repository.activeDatabaseUrl
    val lastSimulatedNotification: StateFlow<IPTVNotification?> = repository.lastSimulatedNotification

    // Language Management state (Changed default to Arabic)
    private val _language = MutableStateFlow(AppLanguage.AR)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    fun toggleLanguage() {
        _language.value = if (_language.value == AppLanguage.EN) AppLanguage.AR else AppLanguage.EN
    }

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
    }

    // --- USER SESSION & AUTHENTICATION STATES ---
    private val sharedPrefs = application.getSharedPreferences("ishtar_accounts", android.content.Context.MODE_PRIVATE)

    private val _currentUser = MutableStateFlow<String?>(sharedPrefs.getString("logged_in_user", null))
    val currentUser: StateFlow<String?> = _currentUser.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _appUsers = MutableStateFlow<List<com.example.model.AppUser>>(emptyList())
    val appUsers: StateFlow<List<com.example.model.AppUser>> = _appUsers.asStateFlow()

    // Currently selected channel for player
    private val _selectedChannel = MutableStateFlow<Channel?>(null)
    val selectedChannel: StateFlow<Channel?> = _selectedChannel.asStateFlow()

    // Screen Management state
    // Tabs: 0 = Live TV, 1 = News, 2 = Match Schedule, 3 = Notifications, 4 = Admin Console
    private val _currentTab = MutableStateFlow(0) 
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    // Flag for Admin Tab Unlocked/Visible (starts hidden completely for normal users)
    private val _isAdminTabUnlocked = MutableStateFlow(false)
    val isAdminTabUnlocked: StateFlow<Boolean> = _isAdminTabUnlocked.asStateFlow()

    fun unlockAdminTab() {
        _isAdminTabUnlocked.value = true
    }

    fun lockAdminTab() {
        _isAdminTabUnlocked.value = false
        _isAdminAuthenticated.value = false
        // If we are currently on the administrative tab, switch back to home Live TV!
        if (_currentTab.value == 4) {
            _currentTab.value = 0
        }
    }

    // States list for News and Matches
    private val _sportsNews = MutableStateFlow<List<SportsNews>>(emptyList())
    val sportsNews: StateFlow<List<SportsNews>> = _sportsNews.asStateFlow()

    private val _matchSchedule = MutableStateFlow<List<MatchSchedule>>(emptyList())
    val matchSchedule: StateFlow<List<MatchSchedule>> = _matchSchedule.asStateFlow()

    // Admin authorization PIN states
    private val _isAdminAuthenticated = MutableStateFlow(false)
    val isAdminAuthenticated: StateFlow<Boolean> = _isAdminAuthenticated.asStateFlow()

    val correctPin = "1234" // Default developer pin for testing
    private val _pinError = MutableStateFlow<String?>(null)
    val pinError: StateFlow<String?> = _pinError.asStateFlow()

    // Form inputs states
    val newChannelName = MutableStateFlow("")
    val newChannelUrl = MutableStateFlow("")
    val newChannelCategory = MutableStateFlow("Premier League")
    val newChannelLogo = MutableStateFlow("")

    val pushTitle = MutableStateFlow("")
    val pushMessage = MutableStateFlow("")

    val customFirebaseUrl = MutableStateFlow("")

    init {
        seedSampleUsersIfNeeded()

        // Automatically make admin tab unlocked if admin is already logged in
        if (_currentUser.value == "Mhmid2002@@" || _currentUser.value == "admin") {
            _isAdminTabUnlocked.value = true
            _isAdminAuthenticated.value = true
        }

        // Seed News
        _sportsNews.value = listOf(
            SportsNews(
                titleAr = "ريال مدريد ينهي استعداداته لنهائي دوري أبطال أوروبا وسط معنويات مرتفعة بجميع عناصره",
                titleEn = "Real Madrid completes final training session before Champions League finale in high spirits",
                descAr = "أنهى نادي ريال مدريد الإسباني حصته التدريبية الأخيرة قبل مواجهة النهائي المنتظرة بنسق تكتيكي مكثف. وشهدت التدريبات معنويات عالية ومشاركة جميع العناصر الأساسية باستثناء المصابين مسبقاً، وتأكيد المدير الفني كارلو أنشيلوتي للصحفيين الجاهزية الذهنية والبدنية التامة للمباراة التاريخية.",
                descEn = "Real Madrid under Carlo Ancelotti has concluded their high-octane final preparations ahead of tomorrow's iconic European showcase. The squad showed tremendous high-spirits in training, with players expressing full commitment alongside a fully fit primary roster looking to bag their next title.",
                imageUrl = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=600&h=300&fit=crop"
            ),
            SportsNews(
                titleAr = "محمد صلاح يتصدر صدارة هدافي الدوري الإنجليزي الممتاز ويقترب من الحذاء الذهبي",
                titleEn = "Mohamed Salah leads the Premier League top-scorers chart for Golden Boot",
                descAr = "يواصل نجمنا العربي المصري محمد صلاح كتابة فصول التاريخ الكروي في بريطانيا، حيث انفرد كلياً بصدارة جدول ترتيب هدافي البريميرليج لهذا الأسبوع، متفوقاً بفارق مريح على أقرب ملاحقيه ومقدماً واحدة من أروع مستوياته التنافسية مع ليفربول.",
                descEn = "Egyptian world-class superstar Mohamed Salah stands sovereign, topping the Premier League's goal-scoring leaderboard yet again. He further secures a solid command in his unrelenting chase after his latest Golden Boot award following back-to-back matchday masterclasses.",
                imageUrl = "https://images.unsplash.com/photo-1543191879-742cb47a8617?w=600&h=300&fit=crop"
            ),
            SportsNews(
                titleAr = "أجواء صراع كلاسيكو الأرض تشتعل لقمة ريال مدريد وبرشلونة الحاسمة للقب الليغا",
                titleEn = "La Liga El Clásico fever peaks as title-decider clash approaches",
                descAr = "دخل صراع القمة في الدوري الإسباني مرحلة بالغة الحساسية، حيث تتجه الأنظار لمباراة كلاسيكو الغريمين. ويسعى الميرنجي لحسم البطولة على أرضه، بينما يدخل الفريق الكتالوني بشعار الفوز ولا بديل عنه لتقليص فارق النقاط وإشعال المنافسة مجدداً.",
                descEn = "The pressure is on in Spain as the El Clasico rivals line up for a monumental gridlock. Real Madrid looks to secure an absolute title head-start, while Barcelona travels containing custom fire strategies where nothing short of a win keeps their campaign hopes glowing.",
                imageUrl = "https://images.unsplash.com/photo-1518063319789-7217e6706b04?w=600&h=300&fit=crop"
            )
        )

        // Seed Matches
        _matchSchedule.value = listOf(
            MatchSchedule(
                homeTeam = "Arsenal",
                awayTeam = "Chelsea",
                homeLogo = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=100&h=100&fit=crop",
                awayLogo = "https://images.unsplash.com/photo-1543191879-742cb47a8617?w=100&h=100&fit=crop",
                matchTime = "78'",
                date = "Today",
                leagueAr = "الدوري الإنجليزي الممتاز",
                leagueEn = "Premier League",
                status = MatchStatus.LIVE
            ),
            MatchSchedule(
                homeTeam = "Manchester City",
                awayTeam = "Liverpool",
                homeLogo = "https://images.unsplash.com/photo-1518063319789-7217e6706b04?w=100&h=100&fit=crop",
                awayLogo = "https://images.unsplash.com/photo-1431324155629-1a6edd1dec1d?w=100&h=100&fit=crop",
                matchTime = "22:30",
                date = "Today",
                leagueAr = "الدوري الإنجليزي الممتاز",
                leagueEn = "Premier League",
                status = MatchStatus.UPCOMING
            ),
            MatchSchedule(
                homeTeam = "Real Madrid",
                awayTeam = "Barcelona",
                homeLogo = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=100&h=100&fit=crop",
                awayLogo = "https://images.unsplash.com/photo-1518063319789-7217e6706b04?w=100&h=100&fit=crop",
                matchTime = "21:00",
                date = "Tomorrow",
                leagueAr = "الدوري الإسباني (الليغا)",
                leagueEn = "La Liga",
                status = MatchStatus.UPCOMING
            ),
            MatchSchedule(
                homeTeam = "Al Hilal",
                awayTeam = "Al Nassr",
                homeLogo = "https://images.unsplash.com/photo-1431324155629-1a6edd1dec1d?w=100&h=100&fit=crop",
                awayLogo = "https://images.unsplash.com/photo-1543191879-742cb47a8617?w=100&h=100&fit=crop",
                matchTime = "FT (2 - 1)",
                date = "Yesterday",
                leagueAr = "الدوري السعودي للمحترفين",
                leagueEn = "Saudi Pro League",
                status = MatchStatus.FINISHED
            )
        )

        // Automatically set the first channel as selected once loaded
        viewModelScope.launch {
            channels.collectLatest { list ->
                if (_selectedChannel.value == null && list.isNotEmpty()) {
                    _selectedChannel.value = list.first()
                }
            }
        }
    }

    fun selectChannel(channel: Channel) {
        _selectedChannel.value = channel
    }

    fun setTab(index: Int) {
        _currentTab.value = index
    }

    // --- SEEDING & USER DB OPERATIONS ---

    fun seedSampleUsersIfNeeded() {
        val allPrefs = sharedPrefs.all
        val hasAnyUser = allPrefs.keys.any { it.startsWith("user_pin_") }
        if (!hasAnyUser) {
            sharedPrefs.edit()
                .putString("user_pin_العقيد_رياض", "1234")
                .putBoolean("user_online_العقيد_رياض", true)
                .putString("user_last_active_العقيد_رياض", "الآن")
                .putBoolean("user_blocked_العقيد_رياض", false)

                .putString("user_pin_أبو_حوراء", "1234")
                .putBoolean("user_online_أبو_حوراء", false)
                .putString("user_last_active_أبو_حوراء", "منذ ساعتين")
                .putBoolean("user_blocked_أبو_حوراء", false)

                .putString("user_pin_كابتن_علي", "1234")
                .putBoolean("user_online_كابتن_علي", true)
                .putString("user_last_active_كابتن_علي", "الآن")
                .putBoolean("user_blocked_كابتن_علي", false)

                .putString("user_pin_مشجع_عراقي", "1234")
                .putBoolean("user_online_مشجع_عراقي", false)
                .putString("user_last_active_مشجع_عراقي", "أمس")
                .putBoolean("user_blocked_مشجع_عراقي", true)
                .apply()
        }
        refreshUsersList()
    }

    fun refreshUsersList() {
        val allPrefs = sharedPrefs.all
        val users = mutableListOf<com.example.model.AppUser>()

        users.add(
            com.example.model.AppUser(
                username = "Mhmid2002@@",
                roleAr = "مسؤول النظام الرئيسي",
                roleEn = "Owner Administrator",
                isOnline = (_currentUser.value == "Mhmid2002@@"),
                lastActive = if (_currentUser.value == "Mhmid2002@@") "نشط الآن" else "منذ ساعات",
                statusAr = "صالح ومتاح",
                statusEn = "Valid & Active",
                pin = "Mhmidmilk200"
            )
        )

        val keys = allPrefs.keys.filter { it.startsWith("user_pin_") }.sorted()
        for (key in keys) {
            val username = key.removePrefix("user_pin_")
            val pin = allPrefs[key]?.toString() ?: "1234"
            val isOnline = sharedPrefs.getBoolean("user_online_$username", false) || (_currentUser.value == username)
            val lastActive = sharedPrefs.getString("user_last_active_$username", "غير متوفر") ?: "غير متوفر"
            val isBlocked = sharedPrefs.getBoolean("user_blocked_$username", false)

            users.add(
                com.example.model.AppUser(
                    username = username,
                    roleAr = "مستخدم التطبيق",
                    roleEn = "Standard App User",
                    isOnline = isOnline,
                    lastActive = lastActive,
                    statusAr = if (isBlocked) "محظور من البث" else "نشط ومصرح له",
                    statusEn = if (isBlocked) "Blocked Access" else "Authorized Active",
                    pin = pin
                )
            )
        }
        _appUsers.value = users
    }

    fun toggleUserBlock(username: String) {
        if (username.lowercase() == "admin" || username == "Mhmid2002@@") return
        val currentlyBlocked = sharedPrefs.getBoolean("user_blocked_$username", false)
        sharedPrefs.edit().putBoolean("user_blocked_$username", !currentlyBlocked).apply()
        refreshUsersList()
    }

    fun toggleUserOnlineStatus(username: String) {
        if (username.lowercase() == "admin" || username == "Mhmid2002@@") return
        val currentlyOnline = sharedPrefs.getBoolean("user_online_$username", false)
        sharedPrefs.edit()
            .putBoolean("user_online_$username", !currentlyOnline)
            .putString("user_last_active_$username", if (!currentlyOnline) "الآن" else "منذ ساعتين")
            .apply()
        refreshUsersList()
    }

    // --- USER REGISTRATION & LOGIN ACTIONS ---

    fun loginUser(usernameEntered: String, pinEntered: String): Boolean {
        val u = usernameEntered.trim()
        val p = pinEntered.trim()
        if (u.isBlank() || p.isBlank()) {
            _authError.value = "يرجى ملء جميع الحقول المطلوبة."
            return false
        }

        // Special handling for the owner/admin account
        if (u == "Mhmid2002@@" || u.lowercase() == "admin") {
            val isCustomValid = (u == "Mhmid2002@@" && p == "Mhmidmilk200")
            val isLegacyValid = (u.lowercase() == "admin" && (p == "admin" || p == "1234"))
            
            if (isCustomValid || isLegacyValid) {
                _currentUser.value = u
                sharedPrefs.edit().putString("logged_in_user", u).apply()
                _isAdminTabUnlocked.value = true
                _isAdminAuthenticated.value = true
                _authError.value = null
                refreshUsersList()
                return true
            } else {
                _authError.value = "كلمة المرور الخاصة بحساب المسؤول غير صحيحة."
                return false
            }
        }

        // Check if user is registered in SharedPreferences
        val savedPin = sharedPrefs.getString("user_pin_$u", null)
        return if (savedPin != null && savedPin == p) {
            if (sharedPrefs.getBoolean("user_blocked_$u", false)) {
                _authError.value = "عذراً! حسابك محظور من دخول التطبيق من قبل الإدارة."
                return false
            }
            _currentUser.value = u
            sharedPrefs.edit()
                .putString("logged_in_user", u)
                .putBoolean("user_online_$u", true)
                .putString("user_last_active_$u", "الآن")
                .apply()
            _isAdminTabUnlocked.value = false
            _isAdminAuthenticated.value = false
            _authError.value = null
            refreshUsersList()
            true
        } else {
            _authError.value = "اسم المستخدم أو كلمة المرور غير صحيحة."
            false
        }
    }

    fun registerUser(usernameEntered: String, pinEntered: String): Boolean {
        val u = usernameEntered.trim()
        val p = pinEntered.trim()
        if (u.isBlank() || p.isBlank()) {
            _authError.value = "يرجى ملء جميع الحقول المطلوبة."
            return false
        }

        if (u.lowercase() == "admin" || u == "Mhmid2002@@") {
            _authError.value = "لا يمكن تسجيل حساب باسم محجوز للمسؤول."
            return false
        }

        // Check if user already exists
        if (sharedPrefs.contains("user_pin_$u")) {
            _authError.value = "اسم المستخدم هذا مسجل بالفعل."
            return false
        }

        // Save account
        sharedPrefs.edit()
            .putString("user_pin_$u", p)
            .putString("logged_in_user", u)
            .putBoolean("user_online_$u", true)
            .putString("user_last_active_$u", "الآن")
            .apply()

        _currentUser.value = u
        _isAdminTabUnlocked.value = false
        _isAdminAuthenticated.value = false
        _authError.value = null
        refreshUsersList()
        return true
    }

    fun logoutCurrent() {
        val oldUser = _currentUser.value
        _currentUser.value = null
        if (oldUser != null && oldUser.lowercase() != "admin" && oldUser != "Mhmid2002@@") {
            sharedPrefs.edit()
                .putBoolean("user_online_$oldUser", false)
                .putString("user_last_active_$oldUser", "منذ ثوانٍ")
                .apply()
        }
        sharedPrefs.edit().remove("logged_in_user").apply()
        _isAdminTabUnlocked.value = false
        _isAdminAuthenticated.value = false
        // Reset navigation to Live TV Tab
        _currentTab.value = 0
        refreshUsersList()
    }

    fun clearAuthError() {
        _authError.value = null
    }

    // --- ADMINISTRATIVE AUTH ACTIONS ---

    fun verifyAdminPin(pinEntered: String): Boolean {
        return if (pinEntered == "Mhmidmilk200" || pinEntered == correctPin) {
            _isAdminAuthenticated.value = true
            _pinError.value = null
            true
        } else {
            _pinError.value = "Incorrect authorization key"
            false
        }
    }

    fun logoutAdmin() {
        _isAdminAuthenticated.value = false
    }

    fun resetPinFields() {
        _pinError.value = null
    }

    // --- REPOSITORY ACTION TRIGGERS ---

    fun createChannel() {
        val name = newChannelName.value.trim()
        val url = newChannelUrl.value.trim()
        val category = newChannelCategory.value.trim()
        val logo = newChannelLogo.value.trim().ifBlank {
            // Unsplash sports visual fallback defaults
            "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=100&h=100&fit=crop"
        }

        if (name.isNotBlank() && url.isNotBlank()) {
            val channel = Channel(
                name = name,
                streamUrl = url,
                category = category,
                logoUrl = logo
            )
            viewModelScope.launch {
                repository.addChannel(channel)
                // Clear input form fields
                newChannelName.value = ""
                newChannelUrl.value = ""
                newChannelLogo.value = ""
            }
        }
    }

    fun removeChannel(id: String) {
        viewModelScope.launch {
            repository.deleteChannel(id)
            // If deleted channel is active, select another
            if (_selectedChannel.value?.id == id) {
                val remaining = channels.value.filter { it.id != id }
                _selectedChannel.value = remaining.firstOrNull()
            }
        }
    }

    fun toggleAds(enabled: Boolean) {
        viewModelScope.launch {
            repository.updateAdSettings(enabled, adSettings.value.adUnitId)
        }
    }

    fun updateAdUnit(unitId: String) {
        viewModelScope.launch {
            repository.updateAdSettings(adSettings.value.adEnabled, unitId.trim())
        }
    }

    fun triggerBroadcastNotification() {
        val title = pushTitle.value.trim()
        val message = pushMessage.value.trim()

        if (title.isNotBlank() && message.isNotBlank()) {
            viewModelScope.launch {
                repository.sendPushNotification(title, message)
                // Clear fields
                pushTitle.value = ""
                pushMessage.value = ""
            }
        }
    }

    fun clearNotificationBubble() {
        viewModelScope.launch {
            repository.clearActiveNotification()
        }
    }

    // --- CONFIGURATION MANAGEMENT ---

    fun applyCustomFirebaseDatabase(url: String) {
        viewModelScope.launch {
            if (url.trim().isBlank()) {
                repository.disconnectFirebase()
            } else {
                repository.configureFirebaseDynamically(url.trim())
            }
        }
    }

    fun resetToLocalSandbox() {
        customFirebaseUrl.value = ""
        viewModelScope.launch {
            repository.disconnectFirebase()
        }
    }
}

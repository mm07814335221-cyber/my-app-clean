package com.example.repository

import android.content.Context
import android.util.Log
import com.example.model.Channel
import com.example.model.IPTVAdSettings
import com.example.model.IPTVNotification
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.database.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class FirebaseRepository(private val context: Context) {
    
    private val TAG = "FirebaseRepository"
    
    // Status flags
    private val _isFirebaseConfigured = MutableStateFlow(false)
    val isFirebaseConfigured: StateFlow<Boolean> = _isFirebaseConfigured.asStateFlow()
    
    private val _activeDatabaseUrl = MutableStateFlow("")
    val activeDatabaseUrl: StateFlow<String> = _activeDatabaseUrl.asStateFlow()

    // Live state flows
    private val _channels = MutableStateFlow<List<Channel>>(emptyList())
    val channels: StateFlow<List<Channel>> = _channels.asStateFlow()

    private val _adSettings = MutableStateFlow(IPTVAdSettings())
    val adSettings: StateFlow<IPTVAdSettings> = _adSettings.asStateFlow()

    private val _notifications = MutableStateFlow<List<IPTVNotification>>(emptyList())
    val notifications: StateFlow<List<IPTVNotification>> = _notifications.asStateFlow()

    private val _lastSimulatedNotification = MutableStateFlow<IPTVNotification?>(null)
    val lastSimulatedNotification: StateFlow<IPTVNotification?> = _lastSimulatedNotification.asStateFlow()

    private var firebaseDatabase: FirebaseDatabase? = null
    private var channelsRef: DatabaseReference? = null
    private var settingsRef: DatabaseReference? = null
    private var notificationsRef: DatabaseReference? = null

    // Fallback Mock Data
    private val mockChannels = mutableListOf(
        Channel(
            id = "mock_1",
            name = "Stamford Pitch Live HD",
            streamUrl = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
            category = "Premier League",
            logoUrl = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=100&h=100&fit=crop"
        ),
        Channel(
            id = "mock_2",
            name = "Champions League Stream (Demo)",
            streamUrl = "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8",
            category = "Champions League",
            logoUrl = "https://images.unsplash.com/photo-1543191879-742cb47a8617?w=100&h=100&fit=crop"
        ),
        Channel(
            id = "mock_3",
            name = "El Clásico Arena (720p)",
            streamUrl = "https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/teears-of-steel.ism/.m3u8",
            category = "La Liga",
            logoUrl = "https://images.unsplash.com/photo-1518063319789-7217e6706b04?w=100&h=100&fit=crop"
        ),
        Channel(
            id = "mock_4",
            name = "World Cup Retro Classics",
            streamUrl = "https://playertest.longtailvideo.com/adaptive/oceans/oceans.m3u8",
            category = "World Cup",
            logoUrl = "https://images.unsplash.com/photo-1431324155629-1a6edd1dec1d?w=100&h=100&fit=crop"
        )
    )

    private var mockAdSettings = IPTVAdSettings(adEnabled = true, adUnitId = "ca-app-pub-3940256099942544/5224354917")
    private val mockNotifications = mutableListOf<IPTVNotification>()

    init {
        // Initialize with high quality sandboxed mock data initially
        updateSandboxState()
        
        // Attempt dynamic initialization of Firebase Database if default configuration exists
        try {
            val app = FirebaseApp.getInstance()
            // If already initialized by system, connect
            connectToFirebaseInstance(app)
        } catch (e: Exception) {
            Log.d(TAG, "Default Firebase app not auto-initialized. Operating in Local Sandbox mode.")
        }
    }

    /**
     * Toggles between standard Dynamic Firebase mode and purely local Sandbox mode
     */
    fun configureFirebaseDynamically(dbUrl: String, apiKey: String = "placeholder-key", appId: String = "placeholder-appid") {
        if (dbUrl.isBlank()) {
            disconnectFirebase()
            return
        }

        try {
            // Uninitialize previous app is tricky, but we can reuse or create a custom app name
            val trimmedUrl = dbUrl.trim()
            val appName = "IPTV_Dynamic_${trimmedUrl.hashCode().coerceAtLeast(0)}"
            
            val options = FirebaseOptions.Builder()
                .setDatabaseUrl(trimmedUrl)
                .setApiKey(apiKey.ifBlank { "placeholder-key" })
                .setApplicationId(appId.ifBlank { "1:12345:android:123456" })
                .build()

            val app = try {
                FirebaseApp.getInstance(appName)
            } catch (e: Exception) {
                FirebaseApp.initializeApp(context, options, appName)
            }

            connectToFirebaseInstance(app, trimmedUrl)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to connect to raw Firebase url", e)
            disconnectFirebase()
        }
    }

    private fun connectToFirebaseInstance(app: FirebaseApp, customUrl: String? = null) {
        try {
            firebaseDatabase = if (customUrl != null) {
                FirebaseDatabase.getInstance(app, customUrl)
            } else {
                FirebaseDatabase.getInstance(app)
            }
            
            _activeDatabaseUrl.value = customUrl ?: firebaseDatabase?.reference?.root?.toString() ?: "Default DB"
            _isFirebaseConfigured.value = true

            // Set references
            channelsRef = firebaseDatabase?.getReference("channels")
            settingsRef = firebaseDatabase?.getReference("settings")
            notificationsRef = firebaseDatabase?.getReference("notifications")

            setupListeners()
            Log.d(TAG, "Successfully connected database listeners at ${_activeDatabaseUrl.value}")
        } catch (e: Exception) {
            Log.e(TAG, "Firebase database instance connection failed", e)
            disconnectFirebase()
        }
    }

    fun disconnectFirebase() {
        // Unsubscribe or nullify refs
        channelsRef = null
        settingsRef = null
        notificationsRef = null
        firebaseDatabase = null
        
        _isFirebaseConfigured.value = false
        _activeDatabaseUrl.value = ""
        
        // Return to local sandbox
        updateSandboxState()
    }

    private fun setupListeners() {
        // Channels Realtime Sync
        channelsRef?.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<Channel>()
                for (child in snapshot.children) {
                    val channel = child.getValue(Channel::class.java)
                    if (channel != null) {
                        list.add(channel.copy(id = child.key ?: channel.id))
                    }
                }
                
                // If remote database is completely empty let's fill it with some seed data so they don't get empty screens
                if (list.isEmpty()) {
                    Log.d(TAG, "Remote DTB is empty, writing default seed data")
                    seedDefaultData()
                } else {
                    _channels.value = list
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Channels listener cancelled", error.toException())
            }
        })

        // Settings Realtime Sync
        settingsRef?.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val settings = snapshot.getValue(IPTVAdSettings::class.java)
                if (settings != null) {
                    _adSettings.value = settings
                } else {
                    // Seed settings if missing
                    settingsRef?.setValue(IPTVAdSettings())
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Settings listener cancelled", error.toException())
            }
        })

        // Notifications Realtime Sync
        notificationsRef?.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<IPTVNotification>()
                for (child in snapshot.children) {
                    val notif = child.getValue(IPTVNotification::class.java)
                    if (notif != null) {
                        list.add(notif.copy(id = child.key ?: notif.id))
                    }
                }
                _notifications.value = list.sortedByDescending { it.timestamp }
            }
            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Notifications listener cancelled", error.toException())
            }
        })
    }

    private fun seedDefaultData() {
        // Push mocks to online database for demonstration
        mockChannels.forEach { channel ->
            channelsRef?.child(channel.id)?.setValue(channel)
        }
        settingsRef?.setValue(mockAdSettings)
    }

    private fun updateSandboxState() {
        _channels.value = mockChannels.toList()
        _adSettings.value = mockAdSettings
        _notifications.value = mockNotifications.toList()
    }

    // --- CRUD WRITES FOR CHANNELS ---

    fun addChannel(channel: Channel) {
        val finalChannel = if (channel.id.isBlank()) channel.copy(id = UUID.randomUUID().toString()) else channel
        if (_isFirebaseConfigured.value) {
            channelsRef?.child(finalChannel.id)?.setValue(finalChannel)
                ?.addOnFailureListener {
                    Log.e(TAG, "Failed writing channel to Firebase database", it)
                }
        } else {
            // Local Sandbox State Update
            mockChannels.add(finalChannel)
            updateSandboxState()
        }
    }

    fun deleteChannel(id: String) {
        if (_isFirebaseConfigured.value) {
            channelsRef?.child(id)?.removeValue()
                ?.addOnFailureListener {
                    Log.e(TAG, "Failed deleting channel from Firebase database", it)
                }
        } else {
            mockChannels.removeAll { it.id == id }
            updateSandboxState()
        }
    }

    // --- WRITE FOR SETTINGS ---

    fun updateAdSettings(adEnabled: Boolean, adUnitId: String) {
        val newSettings = IPTVAdSettings(adEnabled = adEnabled, adUnitId = adUnitId)
        if (_isFirebaseConfigured.value) {
            settingsRef?.setValue(newSettings)
                ?.addOnFailureListener {
                    Log.e(TAG, "Failed updating settings in Firebase database", it)
                }
        } else {
            mockAdSettings = newSettings
            updateSandboxState()
        }
    }

    // --- TRANSMIT FCM/PUSH NOTIFICATION ---

    fun sendPushNotification(title: String, message: String) {
        val notification = IPTVNotification(
            id = UUID.randomUUID().toString(),
            title = title,
            message = message,
            timestamp = System.currentTimeMillis()
        )

        if (_isFirebaseConfigured.value) {
            // Save to database which triggers alerts
            notificationsRef?.child(notification.id)?.setValue(notification)
                ?.addOnFailureListener {
                    Log.e(TAG, "Failed writing notification to Firebase database", it)
                }
            
            // Note: Cloud Messaging client broadcast can be done via Firebase Cloud Function
            // or HTTP mock call or simulated here on client for preview
            simulateFCMSend(notification)
        } else {
            // Local sandbox mode simulation
            mockNotifications.add(0, notification)
            updateSandboxState()
            simulateFCMSend(notification)
        }
    }

    private fun simulateFCMSend(notification: IPTVNotification) {
        _lastSimulatedNotification.value = notification
    }

    fun clearActiveNotification() {
        _lastSimulatedNotification.value = null
    }
}
